# README - RAFT CONSENSUS SIMULATION
## by: JuraganSister ( Faza - Rudi - Dyas )

Pada tugas IF3230 Sistem Terdistribusi kali ini, kelompok JuraganSister akan memperkenalkan
simulasi Raft Consensus yang kami buat dengan implementasi berbahasa Python. Cara menggunakannya 
yaitu:

> 1. Network yang dipakai pada setiap node harus sama
> 2. Untuk membuat node-node server, dapat dilakukan dengan command "python test_nodes.py <Jumlah Node>"
> 3. Untuk menggunakan worker (menghitung bilangan prima ke-N), user harus menyalakan dahulu program worker pada setiap PC, dengan command "python3 worker.py"
> 4. Lalu, user dapat memasukkan request dengan memasukkan di browser misalnya "http://192.168.42.81:8000/3" untuk bilangan prima ke-3 (tergantung server yang sedang menyala), dan akan ditampilkan hasilnya langsung

Selamat mencoba! Semoga berhasil! :D



Salam,


JuraganSister


Faza Thirafi  |  Cut Meurah Rudi  | Drestanto M Dyasputro
  13514033    |     13514057      |       13514099
