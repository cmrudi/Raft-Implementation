class Get:
	def __init__(self) :
		self.text = "0"
		self.status_code = 99